#!/bin/bash

# ============================================================
#   HostPro — Ubuntu 24 LTS Auto Install
#   Nginx + PHP-FPM + SSL + Systemd
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()     { echo -e "${GREEN}[✔]${NC} $1"; }
info()    { echo -e "${CYAN}[i]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✘]${NC} $1"; exit 1; }
section() { echo -e "\n${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  $1\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"; }

clear
echo -e "${CYAN}${BOLD}"
cat << 'BANNER'
  _   _           _   ____
 | | | | ___  ___| |_|  _ \ _ __ ___
 | |_| |/ _ \/ __| __| |_) | '__/ _ \
 |  _  | (_) \__ \ |_|  __/| | | (_) |
 |_| |_|\___/|___/\__|_|   |_|  \___/

 Control Panel — Ubuntu 24 LTS Installer
BANNER
echo -e "${NC}"

[[ $EUID -ne 0 ]] && error "Run with sudo: sudo bash install.sh"

section "Configuration"

echo -e "${BOLD}Domain (e.g. panel.yourdomain.com):${NC}"
read -rp "  → " DOMAIN
[[ -z "$DOMAIN" ]] && error "Domain cannot be empty."

echo -e "\n${BOLD}Email for SSL certificate:${NC}"
read -rp "  → " EMAIL
[[ -z "$EMAIL" ]] && error "Email cannot be empty."

echo -e "\n${BOLD}Install Let's Encrypt SSL? (y/n):${NC}"
read -rp "  → " DO_SSL_IN
[[ "$DO_SSL_IN" == "y" ]] && DO_SSL=true || DO_SSL=false

WEBROOT="/var/www/hostpro"

echo ""
echo -e "${CYAN}Summary:${NC}"
echo -e "  Domain  : ${BOLD}$DOMAIN${NC}"
echo -e "  SSL     : ${BOLD}$([ "$DO_SSL" = true ] && echo 'Yes (Let'\''s Encrypt)' || echo 'No')${NC}"
echo -e "  Webroot : ${BOLD}$WEBROOT${NC}"
echo ""
echo -e "${YELLOW}Continue? (y/n):${NC}"
read -rp "  → " CONFIRM
[[ "$CONFIRM" != "y" ]] && exit 0

START=$(date +%s)

section "1/5 — System Update"
apt-get update -qq && apt-get upgrade -y -qq
apt-get install -y -qq curl wget unzip git ufw
log "System updated."

section "2/5 — Nginx"
if ! command -v nginx &>/dev/null; then
  apt-get install -y -qq nginx
fi
systemctl enable nginx && systemctl start nginx
log "Nginx running."

section "3/5 — Deploy HostPro Files"
mkdir -p "$WEBROOT"
cp "${SCRIPT_DIR}/index.html" "$WEBROOT/index.html"
chown -R www-data:www-data "$WEBROOT"
chmod -R 755 "$WEBROOT"
log "Files deployed to $WEBROOT"

section "4/5 — Nginx Virtual Host"
cat > /etc/nginx/sites-available/hostpro << NGINXCONF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    root $WEBROOT;
    index index.html;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    location / { try_files \$uri \$uri/ /index.html; }

    gzip on;
    gzip_types text/html text/css application/javascript;

    location ~* \.(css|js|ico|png|jpg|svg|woff2?)$ {
      expires 30d;
      add_header Cache-Control "public, immutable";
    }

    access_log /var/log/nginx/hostpro_access.log;
    error_log  /var/log/nginx/hostpro_error.log;
}
NGINXCONF

[[ -L /etc/nginx/sites-enabled/default ]] && rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/hostpro /etc/nginx/sites-enabled/hostpro
nginx -t 2>/dev/null && systemctl reload nginx
log "Nginx configured."

if [[ "$DO_SSL" == "true" ]]; then
  section "4.5/5 — SSL (Let's Encrypt)"
  if ! command -v certbot &>/dev/null; then
    apt-get install -y -qq certbot python3-certbot-nginx
  fi
  certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
    --email "$EMAIL" --redirect 2>/dev/null \
    && log "SSL installed." \
    || warn "SSL failed. Check DNS A record points to this server."
  systemctl enable certbot.timer 2>/dev/null || true
  systemctl start certbot.timer 2>/dev/null || true
fi

section "5/5 — Systemd Service & UFW"
cat > /etc/systemd/system/hostpro.service << SYSTEMD
[Unit]
Description=HostPro Control Panel
After=network.target nginx.service
Requires=nginx.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/systemctl start nginx
ExecStop=/bin/systemctl stop nginx
User=root

[Install]
WantedBy=multi-user.target
SYSTEMD

systemctl daemon-reload && systemctl enable hostpro
log "hostpro.service enabled."

if command -v ufw &>/dev/null; then
  ufw allow 'Nginx Full' 2>/dev/null || true
  ufw allow OpenSSH 2>/dev/null || true
  log "UFW: HTTP, HTTPS, SSH allowed."
fi

ELAPSED=$(( $(date +%s) - START ))
PROTO="http"; [[ "$DO_SSL" == "true" ]] && PROTO="https"

echo ""
echo -e "${BOLD}${GREEN}"
echo "  ┌────────────────────────────────────────────┐"
echo "  │   HostPro installed successfully! 🎉       │"
echo "  ├────────────────────────────────────────────┤"
echo -e "  │  URL    : ${CYAN}${PROTO}://${DOMAIN}${GREEN}"
echo -e "  │  Webroot: ${CYAN}${WEBROOT}${GREEN}"
echo -e "  │  Time   : ${CYAN}${ELAPSED}s${GREEN}"
echo "  └────────────────────────────────────────────┘"
echo -e "${NC}"
echo -e "  systemctl status hostpro"
echo -e "  tail -f /var/log/nginx/hostpro_access.log"
echo ""
