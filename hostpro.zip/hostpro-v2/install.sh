#!/bin/bash

# ============================================================
#   HostPro v2 — Ubuntu 24 LTS Auto Install
#   Nginx + PHP 8.3-FPM + MySQL + SSL + Systemd
#   Owner: wpspoti · Repo: hostpro
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()     { echo -e "${GREEN}[✔]${NC} $1"; }
info()    { echo -e "${CYAN}[i]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✘]${NC} $1"; exit 1; }
section() { echo -e "\n${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  $1\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"; }
step()    { echo -e "  ${YELLOW}→${NC} $1"; }

clear
echo -e "${CYAN}${BOLD}"
cat << 'BANNER'
  _   _           _   ____
 | | | | ___  ___| |_|  _ \ _ __ ___
 | |_| |/ _ \/ __| __| |_) | '__/ _ \
 |  _  | (_) \__ \ |_|  __/| | | (_) |
 |_| |_|\___/|___/\__|_|   |_|  \___/

 Control Panel v2 — Full Stack Edition
 Ubuntu 24 LTS · PHP 8.3 · MySQL · Nginx
BANNER
echo -e "${NC}"

[[ $EUID -ne 0 ]] && error "Run with sudo: sudo bash install.sh"

section "Configuration"

echo -e "${BOLD}Domain (e.g. panel.yourdomain.com):${NC}"
read -rp "  → " DOMAIN
[[ -z "$DOMAIN" ]] && error "Domain cannot be empty."

echo -e "\n${BOLD}Email for SSL certificate:${NC}"
read -rp "  → " EMAIL
[[ -z "$EMAIL" ]] && error "Email cannot be empty."

echo -e "\n${BOLD}MySQL root password (blank = auto-generate):${NC}"
read -rsp "  → " MYSQL_ROOT_PASS
echo ""
[[ -z "$MYSQL_ROOT_PASS" ]] && MYSQL_ROOT_PASS=$(openssl rand -base64 16)

echo -e "\n${BOLD}Install Let's Encrypt SSL? (y/n):${NC}"
read -rp "  → " DO_SSL_IN
[[ "$DO_SSL_IN" == "y" ]] && DO_SSL=true || DO_SSL=false

WEBROOT="/var/www/hostpro"
PHP_VER="8.3"
START=$(date +%s)

echo ""
echo -e "${CYAN}Summary:${NC}"
echo -e "  Domain  : ${BOLD}$DOMAIN${NC}"
echo -e "  SSL     : ${BOLD}$([ "$DO_SSL" = true ] && echo 'Yes (Let'\''s Encrypt)' || echo 'No')${NC}"
echo -e "  PHP     : ${BOLD}$PHP_VER-FPM${NC}"
echo -e "  Webroot : ${BOLD}$WEBROOT${NC}"
echo -e "\n${YELLOW}Continue? (y/n):${NC}"
read -rp "  → " CONFIRM
[[ "$CONFIRM" != "y" ]] && exit 0

# ════════════════════════════════════════════════════
section "1/6 — System Update"
# ════════════════════════════════════════════════════
step "Updating packages..."
apt-get update -qq
apt-get upgrade -y -qq
apt-get install -y -qq curl wget unzip git ufw openssl software-properties-common
log "System updated."

# ════════════════════════════════════════════════════
section "2/6 — PHP 8.3 + FPM"
# ════════════════════════════════════════════════════
step "Adding PHP PPA..."
add-apt-repository ppa:ondrej/php -y -q 2>/dev/null
apt-get update -qq

step "Installing PHP $PHP_VER and extensions..."
apt-get install -y -qq \
    php${PHP_VER} \
    php${PHP_VER}-fpm \
    php${PHP_VER}-cli \
    php${PHP_VER}-mysql \
    php${PHP_VER}-mbstring \
    php${PHP_VER}-xml \
    php${PHP_VER}-curl \
    php${PHP_VER}-zip \
    php${PHP_VER}-bcmath \
    php${PHP_VER}-json \
    php${PHP_VER}-gd

systemctl enable php${PHP_VER}-fpm
systemctl start php${PHP_VER}-fpm
log "PHP $PHP_VER-FPM installed and running."

# ════════════════════════════════════════════════════
section "3/6 — MySQL 8"
# ════════════════════════════════════════════════════
if ! command -v mysql &>/dev/null; then
    step "Installing MySQL Server..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq mysql-server
    systemctl enable mysql
    systemctl start mysql
fi

step "Securing MySQL..."
mysql -u root 2>/dev/null <<MYSQL_SETUP || true
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
DELETE FROM mysql.user WHERE User='';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost','127.0.0.1','::1');
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;
MYSQL_SETUP
log "MySQL secured."

# ════════════════════════════════════════════════════
section "4/6 — Nginx"
# ════════════════════════════════════════════════════
if ! command -v nginx &>/dev/null; then
    step "Installing Nginx..."
    apt-get install -y -qq nginx
fi
systemctl enable nginx
systemctl start nginx
log "Nginx installed."

# ════════════════════════════════════════════════════
section "5/6 — Deploy HostPro"
# ════════════════════════════════════════════════════
step "Creating directories..."
mkdir -p "$WEBROOT/api"
mkdir -p /etc/hostpro
mkdir -p /var/log/hostpro
mkdir -p /var/backups/hostpro

step "Copying files..."
cp "${SCRIPT_DIR}/index.html" "$WEBROOT/index.html"
cp "${SCRIPT_DIR}/api/index.php" "$WEBROOT/api/index.php"

step "Setting permissions..."
chown -R www-data:www-data "$WEBROOT"
chmod -R 755 "$WEBROOT"
chown -R www-data:www-data /etc/hostpro
chown -R www-data:www-data /var/log/hostpro
chown -R www-data:www-data /var/backups/hostpro

# Save MySQL root pass to config
cat > /etc/hostpro/config.json << CONFIG
{
  "mysql_root": "${MYSQL_ROOT_PASS}",
  "domain": "${DOMAIN}",
  "installed_at": "$(date -Iseconds)"
}
CONFIG
chmod 600 /etc/hostpro/config.json
chown www-data:www-data /etc/hostpro/config.json

# PHP-FPM needs to run shell commands as root via sudo
step "Configuring sudo for www-data (service management)..."
cat > /etc/sudoers.d/hostpro-www-data << 'SUDO'
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start nginx
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop nginx
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart nginx
www-data ALL=(ALL) NOPASSWD: /bin/systemctl reload nginx
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start mysql
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop mysql
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart mysql
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start postfix
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop postfix
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart postfix
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start redis-server
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop redis-server
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart redis-server
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start fail2ban
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop fail2ban
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart fail2ban
www-data ALL=(ALL) NOPASSWD: /bin/systemctl start cron
www-data ALL=(ALL) NOPASSWD: /bin/systemctl stop cron
www-data ALL=(ALL) NOPASSWD: /bin/systemctl restart cron
www-data ALL=(ALL) NOPASSWD: /usr/bin/certbot
SUDO
chmod 440 /etc/sudoers.d/hostpro-www-data

# Update PHP to allow exec/shell_exec
PHP_INI="/etc/php/${PHP_VER}/fpm/php.ini"
if [ -f "$PHP_INI" ]; then
    step "Enabling exec functions in PHP-FPM..."
    sed -i 's/^disable_functions\s*=.*/disable_functions =/' "$PHP_INI"
    systemctl restart php${PHP_VER}-fpm
fi

step "Writing Nginx config..."
cat > /etc/nginx/sites-available/hostpro << NGINXCONF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;
    root $WEBROOT;
    index index.html index.php;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    # Frontend (SPA)
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # PHP API backend
    location /api/ {
        try_files \$uri \$uri/ /api/index.php?\$query_string;
        location ~ \.php$ {
            fastcgi_pass unix:/var/run/php/php${PHP_VER}-fpm.sock;
            fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
            include fastcgi_params;
            fastcgi_hide_header X-Powered-By;
            fastcgi_read_timeout 120;
        }
    }

    # Block hidden files
    location ~ /\.(?!well-known).* { deny all; }

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_types text/html text/css application/javascript application/json;

    # Cache static files
    location ~* \.(css|js|ico|png|jpg|svg|woff2?)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    access_log /var/log/nginx/hostpro_access.log;
    error_log  /var/log/nginx/hostpro_error.log;
}
NGINXCONF

[[ -L /etc/nginx/sites-enabled/default ]] && rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/hostpro /etc/nginx/sites-enabled/hostpro
nginx -t 2>/dev/null && systemctl reload nginx && log "Nginx configured and reloaded."

# ════════════════════════════════════════════════════
# SSL
# ════════════════════════════════════════════════════
if [[ "$DO_SSL" == "true" ]]; then
    section "5.5/6 — SSL (Let's Encrypt)"
    if ! command -v certbot &>/dev/null; then
        step "Installing Certbot..."
        apt-get install -y -qq certbot python3-certbot-nginx
    fi
    step "Issuing certificate for $DOMAIN..."
    certbot --nginx -d "$DOMAIN" \
        --non-interactive --agree-tos \
        --email "$EMAIL" --redirect 2>/dev/null \
        && log "SSL installed!" \
        || warn "SSL failed. Ensure DNS A record → this server IP. Manual: certbot --nginx -d $DOMAIN"
    systemctl enable certbot.timer 2>/dev/null || true
    systemctl start certbot.timer 2>/dev/null || true
fi

# ════════════════════════════════════════════════════
section "6/6 — Systemd & UFW"
# ════════════════════════════════════════════════════
cat > /etc/systemd/system/hostpro.service << SYSTEMD
[Unit]
Description=HostPro Control Panel (Nginx + PHP-FPM)
After=network.target mysql.service nginx.service php${PHP_VER}-fpm.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c "systemctl start nginx php${PHP_VER}-fpm mysql 2>/dev/null || true"
ExecStop=/bin/bash -c "systemctl stop nginx 2>/dev/null || true"
User=root

[Install]
WantedBy=multi-user.target
SYSTEMD

systemctl daemon-reload
systemctl enable hostpro
log "hostpro.service enabled."

# UFW
if command -v ufw &>/dev/null; then
    step "Configuring UFW..."
    ufw allow 'Nginx Full' 2>/dev/null || true
    ufw allow OpenSSH 2>/dev/null || true
    log "UFW: HTTP, HTTPS, SSH allowed."
fi

# Install Postfix for email (non-interactive)
step "Installing Postfix (mail server)..."
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq postfix 2>/dev/null || true
systemctl enable postfix 2>/dev/null || true

# Install Redis
step "Installing Redis..."
apt-get install -y -qq redis-server 2>/dev/null || true
systemctl enable redis-server 2>/dev/null || true
systemctl start redis-server 2>/dev/null || true

# Install Fail2Ban
step "Installing Fail2Ban..."
apt-get install -y -qq fail2ban 2>/dev/null || true
systemctl enable fail2ban 2>/dev/null || true
systemctl start fail2ban 2>/dev/null || true

# Save credentials
cat > /root/hostpro-credentials.txt << CREDS
HostPro v2 — Installation Info
================================
Date         : $(date)
Domain       : $DOMAIN
Panel URL    : $([ "$DO_SSL" = true ] && echo "https" || echo "http")://$DOMAIN
Webroot      : $WEBROOT
PHP          : $PHP_VER-FPM
API          : $WEBROOT/api/index.php

MySQL
-----
Root Password : $MYSQL_ROOT_PASS

Files
-----
Config       : /etc/hostpro/config.json
Logs         : /var/log/hostpro/
Backups      : /var/backups/hostpro/

Useful Commands
---------------
systemctl status hostpro
tail -f /var/log/nginx/hostpro_access.log
tail -f /var/log/hostpro/activity.log
nginx -t && systemctl reload nginx
certbot renew --dry-run
CREDS
chmod 600 /root/hostpro-credentials.txt

# ════════════════════════════════════════════════════
ELAPSED=$(( $(date +%s) - START ))
PROTO="http"; [[ "$DO_SSL" == "true" ]] && PROTO="https"

echo ""
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║      HostPro v2 Installed Successfully! 🎉      ║"
echo "  ╠══════════════════════════════════════════════════╣"
echo -e "  ║  🌐 Panel : ${CYAN}${PROTO}://${DOMAIN}${GREEN}"
echo -e "  ║  🔌 API   : ${CYAN}${PROTO}://${DOMAIN}/api/index.php${GREEN}"
echo -e "  ║  📁 Root  : ${CYAN}${WEBROOT}${GREEN}"
echo -e "  ║  🐘 PHP   : ${CYAN}${PHP_VER}-FPM${GREEN}"
echo -e "  ║  🔑 Creds : ${CYAN}/root/hostpro-credentials.txt${GREEN}"
echo -e "  ║  ⏱  Time  : ${CYAN}${ELAPSED}s${GREEN}"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "${CYAN}First login:${NC} Open the panel URL and set your admin password."
echo -e "${CYAN}Credentials:${NC} cat /root/hostpro-credentials.txt"
echo ""
