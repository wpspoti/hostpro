<?php
/**
 * HostPro API Backend
 * Handles real system commands for Ubuntu 24 LTS
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

// ── Auth (simple token) ──────────────────────────────────────
define('AUTH_TOKEN_FILE', '/etc/hostpro/.token');
define('CONFIG_FILE',     '/etc/hostpro/config.json');
define('LOG_FILE',        '/var/log/hostpro/activity.log');

function checkAuth() {
    $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
    if (!file_exists(AUTH_TOKEN_FILE)) return true; // first run
    return hash_equals(trim(file_get_contents(AUTH_TOKEN_FILE)), $token);
}

function resp($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function err($msg, $code = 400) {
    resp(['success' => false, 'message' => $msg], $code);
}

function ok($data = []) {
    resp(array_merge(['success' => true], $data));
}

function run($cmd) {
    $output = [];
    $code   = 0;
    exec($cmd . ' 2>&1', $output, $code);
    return ['output' => implode("\n", $output), 'code' => $code];
}

function logActivity($msg) {
    @file_put_contents(LOG_FILE, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND);
}

// ── Router ───────────────────────────────────────────────────
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $action ?: ($input['action'] ?? '');

if (!checkAuth()) err('Unauthorized', 401);

switch ($action) {

    // ════ AUTH ════════════════════════════════════════════════
    case 'login':
        $pass = $input['password'] ?? '';
        $hash_file = '/etc/hostpro/.password';
        if (!file_exists($hash_file)) {
            // First login — set password
            @mkdir('/etc/hostpro', 0700, true);
            file_put_contents($hash_file, password_hash($pass, PASSWORD_BCRYPT));
            $token = bin2hex(random_bytes(32));
            file_put_contents(AUTH_TOKEN_FILE, $token);
            logActivity('First login — password set');
            ok(['token' => $token, 'first_run' => true]);
        }
        if (!password_verify($pass, trim(file_get_contents($hash_file)))) {
            logActivity('Failed login attempt');
            err('Invalid password', 401);
        }
        $token = bin2hex(random_bytes(32));
        file_put_contents(AUTH_TOKEN_FILE, $token);
        logActivity('Admin logged in');
        ok(['token' => $token]);

    // ════ SERVER INFO ════════════════════════════════════════
    case 'server_info':
        $cpu   = trim(shell_exec("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1") ?: '0');
        $mem   = shell_exec("free -m | awk 'NR==2{print $2,$3}'");
        [$mem_total, $mem_used] = array_map('intval', explode(' ', trim($mem)));
        $disk  = shell_exec("df -BG / | awk 'NR==2{print $2,$3,$5}'");
        $dparts = explode(' ', trim($disk));
        $uptime = trim(shell_exec("uptime -p") ?: 'unknown');
        $os     = trim(shell_exec("lsb_release -ds 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME | cut -d'\"' -f2") ?: 'Ubuntu');
        $php    = PHP_VERSION;
        $load   = sys_getloadavg();
        ok([
            'cpu_usage'    => (float)$cpu,
            'ram_used_mb'  => $mem_used,
            'ram_total_mb' => $mem_total,
            'disk_used_gb' => isset($dparts[1]) ? (int)$dparts[1] : 0,
            'disk_total_gb'=> isset($dparts[0]) ? (int)$dparts[0] : 0,
            'disk_pct'     => isset($dparts[2]) ? (int)$dparts[2] : 0,
            'uptime'       => $uptime,
            'os'           => $os,
            'php'          => $php,
            'load_avg'     => $load,
        ]);

    // ════ SERVICES ════════════════════════════════════════════
    case 'services_list':
        $services = ['nginx','mysql','postfix','redis-server','fail2ban','cron'];
        $result = [];
        foreach ($services as $svc) {
            $status = trim(shell_exec("systemctl is-active $svc 2>/dev/null") ?: 'unknown');
            $enabled = trim(shell_exec("systemctl is-enabled $svc 2>/dev/null") ?: 'disabled');
            $result[] = [
                'name'    => $svc,
                'status'  => $status,
                'enabled' => $enabled === 'enabled',
                'running' => $status === 'active',
            ];
        }
        ok(['services' => $result]);

    case 'service_toggle':
        $svc    = preg_replace('/[^a-z0-9\-]/', '', $input['service'] ?? '');
        $act    = in_array($input['action'] ?? '', ['start','stop','restart','reload']) ? $input['action'] : null;
        $allowed = ['nginx','mysql','postfix','redis-server','fail2ban','cron','php8.3-fpm'];
        if (!$svc || !$act || !in_array($svc, $allowed)) err('Invalid service or action');
        $r = run("systemctl $act $svc");
        logActivity("Service $svc $act — exit code: {$r['code']}");
        ok(['output' => $r['output'], 'exit_code' => $r['code']]);

    // ════ DOMAINS ════════════════════════════════════════════
    case 'domains_list':
        $domains = [];
        // Read from /etc/nginx/sites-available
        $files = glob('/etc/nginx/sites-available/*') ?: [];
        foreach ($files as $f) {
            $name = basename($f);
            if (in_array($name, ['default','hostpro'])) continue;
            $enabled = file_exists('/etc/nginx/sites-enabled/' . $name);
            $content = file_get_contents($f);
            preg_match('/server_name\s+([^;]+);/', $content, $m);
            $domains[] = [
                'name'    => trim($m[1] ?? $name),
                'file'    => $f,
                'enabled' => $enabled,
                'status'  => $enabled ? 'active' : 'suspended',
                'ssl'     => file_exists('/etc/letsencrypt/live/' . $name . '/fullchain.pem'),
            ];
        }
        ok(['domains' => $domains]);

    case 'domain_add':
        $domain   = preg_replace('/[^a-z0-9\-\.]/', '', strtolower($input['domain'] ?? ''));
        $webroot  = '/var/www/' . $domain;
        if (!$domain) err('Invalid domain name');
        if (file_exists('/etc/nginx/sites-available/' . $domain)) err('Domain already exists');

        // Create webroot
        @mkdir($webroot, 0755, true);
        file_put_contents($webroot . '/index.html', "<h1>$domain is live!</h1>");
        run("chown -R www-data:www-data $webroot");

        // Nginx config
        $conf = "server {
    listen 80;
    listen [::]:80;
    server_name $domain www.$domain;
    root $webroot;
    index index.html index.php;
    location / { try_files \$uri \$uri/ =404; }
    access_log /var/log/nginx/{$domain}_access.log;
    error_log  /var/log/nginx/{$domain}_error.log;
}";
        file_put_contents('/etc/nginx/sites-available/' . $domain, $conf);
        run('ln -sf /etc/nginx/sites-available/' . $domain . ' /etc/nginx/sites-enabled/' . $domain);
        $r = run('nginx -t && systemctl reload nginx');
        logActivity("Domain added: $domain");
        ok(['domain' => $domain, 'webroot' => $webroot, 'nginx_output' => $r['output']]);

    case 'domain_delete':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', $input['domain'] ?? '');
        if (!$domain) err('Invalid domain');
        @unlink('/etc/nginx/sites-enabled/' . $domain);
        @unlink('/etc/nginx/sites-available/' . $domain);
        run('systemctl reload nginx 2>/dev/null');
        logActivity("Domain deleted: $domain");
        ok(['domain' => $domain]);

    case 'domain_suspend':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', $input['domain'] ?? '');
        @unlink('/etc/nginx/sites-enabled/' . $domain);
        run('systemctl reload nginx 2>/dev/null');
        logActivity("Domain suspended: $domain");
        ok();

    case 'domain_activate':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', $input['domain'] ?? '');
        run('ln -sf /etc/nginx/sites-available/' . $domain . ' /etc/nginx/sites-enabled/' . $domain);
        run('systemctl reload nginx 2>/dev/null');
        logActivity("Domain activated: $domain");
        ok();

    // ════ SSL ════════════════════════════════════════════════
    case 'ssl_list':
        $certs = [];
        $dirs  = glob('/etc/letsencrypt/live/*/') ?: [];
        foreach ($dirs as $dir) {
            $name = basename($dir);
            if ($name === 'README') continue;
            $cert_file = $dir . 'cert.pem';
            $expires = null; $days = 0;
            if (file_exists($cert_file)) {
                $exp_str = shell_exec("openssl x509 -enddate -noout -in $cert_file 2>/dev/null | cut -d= -f2");
                $expires = $exp_str ? date('d M Y', strtotime(trim($exp_str))) : null;
                $days    = $expires ? (int)((strtotime($expires) - time()) / 86400) : 0;
            }
            $certs[] = [
                'domain'  => $name,
                'expires' => $expires,
                'days'    => $days,
                'status'  => $days > 0 ? ($days < 14 ? 'expiring' : 'active') : 'expired',
                'issuer'  => "Let's Encrypt",
            ];
        }
        ok(['certs' => $certs]);

    case 'ssl_install':
        $domain = preg_replace('/[^a-z0-9\-\.\*]/', '', $input['domain'] ?? '');
        $email  = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
        $method = $input['method'] ?? 'http';
        if (!$domain || !$email) err('Domain and email required');

        if ($method === 'dns') {
            $cmd = "certbot certonly --manual --preferred-challenges dns -d $domain -d *.$domain --agree-tos --email $email --non-interactive 2>&1";
        } else {
            $cmd = "certbot --nginx -d $domain --agree-tos --email $email --non-interactive --redirect 2>&1";
        }
        $r = run($cmd);
        $success = strpos($r['output'], 'Congratulations') !== false || strpos($r['output'], 'Successfully') !== false;
        logActivity("SSL install for $domain — " . ($success ? 'success' : 'failed'));
        if (!$success) err('SSL installation failed: ' . $r['output']);
        ok(['output' => $r['output'], 'domain' => $domain]);

    case 'ssl_renew':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', $input['domain'] ?? '');
        $r = run("certbot renew --cert-name $domain --force-renewal 2>&1");
        logActivity("SSL renew for $domain");
        ok(['output' => $r['output']]);

    case 'ssl_delete':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', $input['domain'] ?? '');
        $r = run("certbot delete --cert-name $domain --non-interactive 2>&1");
        logActivity("SSL deleted for $domain");
        ok(['output' => $r['output']]);

    // ════ DATABASES ════════════════════════════════════════════
    case 'db_list':
        $cfg  = json_decode(@file_get_contents(CONFIG_FILE) ?: '{}', true);
        $pass = $cfg['mysql_root'] ?? '';
        $r    = run("mysql -u root " . ($pass ? "-p'$pass'" : "") . " -e 'SHOW DATABASES;' 2>/dev/null");
        $skip = ['Database','information_schema','performance_schema','mysql','sys'];
        $dbs  = array_filter(explode("\n", $r['output']), fn($d) => $d && !in_array($d, $skip));
        $result = [];
        foreach (array_values($dbs) as $db) {
            $size = trim(shell_exec("mysql -u root " . ($pass ? "-p'$pass'" : "") . " -e \"SELECT ROUND(SUM(data_length+index_length)/1024/1024,1) FROM information_schema.tables WHERE table_schema='$db';\" 2>/dev/null | tail -1") ?: '0');
            $tables = trim(shell_exec("mysql -u root " . ($pass ? "-p'$pass'" : "") . " -e \"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$db';\" 2>/dev/null | tail -1") ?: '0');
            $result[] = ['name' => $db, 'size_mb' => (float)$size, 'tables' => (int)$tables];
        }
        ok(['databases' => $result]);

    case 'db_create':
        $cfg  = json_decode(@file_get_contents(CONFIG_FILE) ?: '{}', true);
        $rpass = $cfg['mysql_root'] ?? '';
        $name  = preg_replace('/[^a-z0-9_]/', '', strtolower($input['name'] ?? ''));
        $user  = preg_replace('/[^a-z0-9_]/', '', strtolower($input['username'] ?? $name . '_user'));
        $pass  = $input['password'] ?? bin2hex(random_bytes(8));
        if (!$name) err('Invalid database name');
        $mysql = "mysql -u root " . ($rpass ? "-p'$rpass'" : "");
        run("$mysql -e \"CREATE DATABASE IF NOT EXISTS \`$name\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\"");
        run("$mysql -e \"CREATE USER IF NOT EXISTS '$user'@'localhost' IDENTIFIED BY '$pass';\"");
        run("$mysql -e \"GRANT ALL PRIVILEGES ON \`$name\`.* TO '$user'@'localhost'; FLUSH PRIVILEGES;\"");
        logActivity("Database created: $name");
        ok(['name' => $name, 'username' => $user, 'password' => $pass]);

    case 'db_delete':
        $cfg   = json_decode(@file_get_contents(CONFIG_FILE) ?: '{}', true);
        $rpass = $cfg['mysql_root'] ?? '';
        $name  = preg_replace('/[^a-z0-9_]/', '', $input['name'] ?? '');
        $mysql = "mysql -u root " . ($rpass ? "-p'$rpass'" : "");
        run("$mysql -e \"DROP DATABASE IF EXISTS \`$name\`;\"");
        logActivity("Database deleted: $name");
        ok();

    case 'db_backup':
        $cfg   = json_decode(@file_get_contents(CONFIG_FILE) ?: '{}', true);
        $rpass = $cfg['mysql_root'] ?? '';
        $name  = preg_replace('/[^a-z0-9_]/', '', $input['name'] ?? '');
        $file  = "/var/backups/hostpro/{$name}_" . date('Ymd_His') . '.sql.gz';
        @mkdir('/var/backups/hostpro', 0755, true);
        $r = run("mysqldump -u root " . ($rpass ? "-p'$rpass'" : "") . " $name | gzip > $file");
        logActivity("DB backup: $name → $file");
        ok(['file' => $file, 'size' => file_exists($file) ? round(filesize($file)/1024, 1) . ' KB' : '0']);

    // ════ EMAIL ACCOUNTS ════════════════════════════════════════
    case 'email_list':
        $accounts = [];
        // Read from /etc/postfix/virtual or local passwd
        if (file_exists('/etc/postfix/virtual')) {
            $lines = file('/etc/postfix/virtual', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos($line, '@') !== false && strpos($line, '#') !== 0) {
                    $parts = preg_split('/\s+/', $line);
                    $accounts[] = ['address' => $parts[0], 'target' => $parts[1] ?? ''];
                }
            }
        }
        ok(['accounts' => $accounts]);

    case 'email_create':
        $addr = filter_var($input['address'] ?? '', FILTER_VALIDATE_EMAIL);
        $pass = $input['password'] ?? bin2hex(random_bytes(8));
        if (!$addr) err('Invalid email address');
        [$user, $domain] = explode('@', $addr);
        // Add to virtual mailbox
        $vfile = '/etc/postfix/virtual';
        file_put_contents($vfile, "$addr $user\n", FILE_APPEND);
        run('postmap /etc/postfix/virtual 2>/dev/null');
        run('systemctl reload postfix 2>/dev/null');
        logActivity("Email created: $addr");
        ok(['address' => $addr, 'password' => $pass]);

    case 'email_delete':
        $addr = filter_var($input['address'] ?? '', FILTER_VALIDATE_EMAIL);
        if (!$addr) err('Invalid email');
        $vfile = '/etc/postfix/virtual';
        if (file_exists($vfile)) {
            $lines = file($vfile, FILE_IGNORE_NEW_LINES);
            $filtered = array_filter($lines, fn($l) => strpos($l, $addr) === false);
            file_put_contents($vfile, implode("\n", $filtered) . "\n");
            run('postmap /etc/postfix/virtual 2>/dev/null');
            run('systemctl reload postfix 2>/dev/null');
        }
        logActivity("Email deleted: $addr");
        ok();

    // ════ FILE MANAGER ════════════════════════════════════════
    case 'files_list':
        $path = realpath($input['path'] ?? '/var/www');
        // Security: restrict to /var/www
        if (!$path || strpos($path, '/var/www') !== 0) err('Access denied');
        $items = [];
        foreach (scandir($path) as $f) {
            if ($f === '.' || $f === '..') continue;
            $full = $path . '/' . $f;
            $items[] = [
                'name'     => $f,
                'type'     => is_dir($full) ? 'dir' : 'file',
                'size'     => is_file($full) ? filesize($full) : 0,
                'modified' => date('Y-m-d H:i', filemtime($full)),
                'perms'    => substr(sprintf('%o', fileperms($full)), -4),
            ];
        }
        usort($items, fn($a,$b) => $a['type'] === $b['type'] ? strcmp($a['name'],$b['name']) : ($a['type']==='dir' ? -1 : 1));
        ok(['path' => $path, 'items' => $items]);

    case 'files_read':
        $path = realpath($input['path'] ?? '');
        if (!$path || strpos($path, '/var/www') !== 0 || !is_file($path)) err('File not found or access denied');
        if (filesize($path) > 512 * 1024) err('File too large (max 512KB)');
        ok(['content' => file_get_contents($path), 'path' => $path]);

    case 'files_write':
        $path = $input['path'] ?? '';
        if (!$path || strpos(realpath(dirname($path)), '/var/www') !== 0) err('Access denied');
        file_put_contents($path, $input['content'] ?? '');
        logActivity("File written: $path");
        ok();

    case 'files_delete':
        $path = realpath($input['path'] ?? '');
        if (!$path || strpos($path, '/var/www') !== 0) err('Access denied');
        if (is_dir($path)) { run("rm -rf $path"); }
        else { @unlink($path); }
        logActivity("File deleted: $path");
        ok();

    case 'files_mkdir':
        $path = $input['path'] ?? '';
        if (!$path || strpos($path, '/var/www') !== 0) err('Access denied');
        @mkdir($path, 0755, true);
        ok(['path' => $path]);

    // ════ BACKUPS ════════════════════════════════════════════
    case 'backup_create':
        $type = $input['type'] ?? 'full';
        @mkdir('/var/backups/hostpro', 0755, true);
        $file = '/var/backups/hostpro/backup_' . $type . '_' . date('Ymd_His') . '.tar.gz';
        if ($type === 'full') {
            run("tar -czf $file /var/www 2>/dev/null");
        } elseif ($type === 'files') {
            run("tar -czf $file /var/www 2>/dev/null");
        }
        $size = file_exists($file) ? round(filesize($file)/1024/1024, 1) : 0;
        logActivity("Backup created: $file ($size MB)");
        ok(['file' => $file, 'size_mb' => $size]);

    case 'backup_list':
        $files = glob('/var/backups/hostpro/*.tar.gz') ?: [];
        $list  = [];
        foreach ($files as $f) {
            $list[] = [
                'file'     => basename($f),
                'path'     => $f,
                'size_mb'  => round(filesize($f)/1024/1024, 1),
                'created'  => date('Y-m-d H:i', filemtime($f)),
            ];
        }
        usort($list, fn($a,$b) => strcmp($b['created'], $a['created']));
        ok(['backups' => $list]);

    // ════ LOGS ════════════════════════════════════════════════
    case 'logs':
        $type  = $input['type'] ?? 'activity';
        $lines = min((int)($input['lines'] ?? 50), 200);
        $files = [
            'activity' => LOG_FILE,
            'nginx'    => '/var/log/nginx/hostpro_access.log',
            'error'    => '/var/log/nginx/hostpro_error.log',
            'mysql'    => '/var/log/mysql/error.log',
            'system'   => '/var/log/syslog',
        ];
        $file = $files[$type] ?? LOG_FILE;
        $content = trim(shell_exec("tail -n $lines $file 2>/dev/null") ?: 'No logs found.');
        ok(['content' => $content, 'file' => $file]);

    // ════ PHP INFO ════════════════════════════════════════════
    case 'php_versions':
        $installed = [];
        foreach (['7.4','8.0','8.1','8.2','8.3'] as $v) {
            if (file_exists("/usr/bin/php$v") || trim(shell_exec("which php$v 2>/dev/null"))) {
                $installed[] = $v;
            }
        }
        $current = PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION;
        ok(['versions' => $installed, 'current' => $current]);

    // ════ FIREWALL (UFW) ══════════════════════════════════════
    case 'firewall_status':
        $status  = trim(shell_exec('ufw status verbose 2>/dev/null') ?: 'UFW not installed');
        $enabled = strpos($status, 'Status: active') !== false;
        // Parse rules
        $rules = [];
        $lines = explode("\n", $status);
        foreach ($lines as $line) {
            if (preg_match('/^(\S+.*?)\s+(ALLOW|DENY|REJECT|LIMIT)\s+(IN|OUT|FWD)?\s*(.*)$/i', trim($line), $m)) {
                $rules[] = [
                    'port'      => trim($m[1]),
                    'policy'    => strtolower($m[2]),
                    'direction' => strtolower($m[3] ?: 'in'),
                    'from'      => trim($m[4] ?: 'Anywhere'),
                ];
            }
        }
        ok(['enabled' => $enabled, 'status' => $status, 'rules' => $rules]);

    case 'firewall_rule':
        $act  = $input['rule_action'] ?? ''; // allow | deny | delete
        $port = preg_replace('/[^a-z0-9\/\:\. ]/', '', strtolower($input['port'] ?? ''));
        $from = preg_replace('/[^a-z0-9\.\:\/]/', '', $input['from'] ?? '');
        if (!$port) err('Port is required');
        $allowed_actions = ['allow','deny','reject','delete','enable','disable'];
        if (!in_array($act, $allowed_actions)) err('Invalid action');
        if ($act === 'enable')  { $r = run('ufw --force enable 2>&1');  logActivity('UFW enabled');  ok(['output' => $r['output']]); }
        if ($act === 'disable') { $r = run('ufw disable 2>&1');         logActivity('UFW disabled'); ok(['output' => $r['output']]); }
        $from_part = $from ? "from $from to any port $port" : $port;
        if ($act === 'delete') {
            $r = run("ufw delete $act $from_part 2>&1");
        } else {
            $r = run("ufw $act $from_part 2>&1");
        }
        logActivity("Firewall rule: $act $port" . ($from ? " from $from" : ''));
        ok(['output' => $r['output'], 'exit_code' => $r['code']]);

    // ════ PHP SWITCH ═════════════════════════════════════════
    case 'php_switch':
        $version = preg_replace('/[^0-9\.]/', '', $input['version'] ?? '');
        if (!$version || !in_array($version, ['7.4','8.0','8.1','8.2','8.3'])) err('Invalid PHP version');
        if (!file_exists("/usr/bin/php$version")) err("PHP $version is not installed");
        // Update default CLI
        $r1 = run("update-alternatives --set php /usr/bin/php$version 2>&1");
        // Reload PHP-FPM for the target version
        $r2 = run("systemctl reload php$version-fpm 2>/dev/null || systemctl start php$version-fpm 2>&1");
        // Update Nginx fastcgi_pass if possible
        $r3 = run("sed -i 's/php[0-9\.]*-fpm/php$version-fpm/g' /etc/nginx/sites-enabled/* 2>/dev/null && nginx -t && systemctl reload nginx 2>&1");
        logActivity("PHP switched to $version");
        ok([
            'version' => $version,
            'cli'     => $r1['output'],
            'fpm'     => $r2['output'],
            'nginx'   => $r3['output'],
        ]);

    // ════ DNS CHECK ═══════════════════════════════════════════
    case 'dns_check':
        $domain = preg_replace('/[^a-z0-9\-\.]/', '', strtolower($input['domain'] ?? ''));
        if (!$domain) err('Domain required');
        $a     = trim(shell_exec("dig +short A $domain 2>/dev/null") ?: 'Not found');
        $aaaa  = trim(shell_exec("dig +short AAAA $domain 2>/dev/null") ?: 'Not found');
        $mx    = trim(shell_exec("dig +short MX $domain 2>/dev/null") ?: 'Not found');
        $ns    = trim(shell_exec("dig +short NS $domain 2>/dev/null") ?: 'Not found');
        $txt   = trim(shell_exec("dig +short TXT $domain 2>/dev/null") ?: 'Not found');
        $cname = trim(shell_exec("dig +short CNAME $domain 2>/dev/null") ?: 'Not found');
        $ptr   = trim(shell_exec("dig +short -x $a 2>/dev/null") ?: 'Not found');
        logActivity("DNS check for $domain");
        ok([
            'domain' => $domain,
            'records' => [
                'A'     => $a,
                'AAAA'  => $aaaa,
                'MX'    => $mx,
                'NS'    => $ns,
                'TXT'   => $txt,
                'CNAME' => $cname,
                'PTR'   => $ptr,
            ]
        ]);

    // ════ FILE UPLOAD ═════════════════════════════════════════
    case 'files_upload':
        $dest_dir = realpath($input['path'] ?? '/var/www');
        if (!$dest_dir || strpos($dest_dir, '/var/www') !== 0) err('Access denied');
        if (empty($_FILES['file'])) err('No file uploaded');
        $file     = $_FILES['file'];
        $filename = basename(preg_replace('/[^a-zA-Z0-9\-_\.\s]/', '', $file['name']));
        if (!$filename) err('Invalid filename');
        $dest = $dest_dir . '/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dest)) err('Upload failed');
        run("chown www-data:www-data $dest");
        logActivity("File uploaded: $dest");
        ok(['file' => $filename, 'path' => $dest, 'size' => filesize($dest)]);

    // ════ BACKUP DELETE ═══════════════════════════════════════
    case 'backup_delete':
        $path = realpath($input['path'] ?? '');
        if (!$path || strpos($path, '/var/backups/hostpro') !== 0) err('Access denied');
        @unlink($path);
        logActivity("Backup deleted: $path");
        ok();

    default:
        err('Unknown action: ' . $action, 404);
}
