# HostPro — Control Panel

A professional cPanel-like hosting control panel with a clean **white & purple** theme.  
Built with pure HTML5 / CSS3 / Vanilla JS — no dependencies required.

## Features

| Category | Features |
|----------|----------|
| 🌐 Domains | Domain manager, subdomains, addon domains, redirects |
| 🔒 SSL | Let's Encrypt installer with 3-step wizard, auto-renew |
| 📁 Files | File Manager, FTP quick access |
| 🗄️ Databases | MySQL database manager, phpMyAdmin link |
| 📧 Email | Email accounts with quota tracking |
| ⚙️ Services | Nginx, MySQL, Postfix, Redis, Fail2Ban toggles |
| 📊 Resources | CPU, RAM, Disk, Bandwidth live gauges |
| 🛡️ Security | Firewall, Fail2Ban, threat counter |
| 💾 Backups | Backup manager |
| 📜 Logs | Activity log, error logs |

## Ubuntu 24 Auto Install

```bash
git clone https://github.com/YOUR_USERNAME/hostpro.git
cd hostpro
chmod +x install.sh
sudo bash install.sh
```

Script will ask:
- **Domain** — e.g. `panel.yourdomain.com`
- **Email** — for SSL certificate
- **SSL?** — Yes/No for Let's Encrypt

Then automatically:
1. Updates system packages
2. Installs & configures Nginx
3. Deploys HostPro files to `/var/www/hostpro`
4. Configures Nginx virtual host (gzip, cache, security headers)
5. Installs Let's Encrypt SSL + auto-renewal (optional)
6. Creates `hostpro.service` systemd service
7. Configures UFW firewall (HTTP, HTTPS, SSH)

## Requirements

- Ubuntu 24 LTS Server
- Root / sudo access
- Domain with DNS A record pointing to server
- Open ports: 80, 443

## Useful Commands

```bash
systemctl status hostpro          # Service status
systemctl restart hostpro         # Restart
nginx -t                          # Test config
certbot renew --dry-run           # Test SSL renewal
tail -f /var/log/nginx/hostpro_access.log  # Live logs
```

## File Structure

```
hostpro/
├── index.html     # Control panel UI
├── install.sh     # Ubuntu 24 auto-installer
└── README.md
```

## License

MIT
