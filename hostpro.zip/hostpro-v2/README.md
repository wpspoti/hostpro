# HostPro v2 — Full Stack Control Panel

> **Owner:** [wpspoti](https://github.com/wpspoti) · **Repo:** `hostpro`  
> A professional cPanel-like hosting control panel. White & purple theme. All buttons fully functional.

## Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5 / CSS3 / Vanilla JS |
| Backend | PHP 8.3 (API) |
| Web Server | Nginx + PHP-FPM |
| Database | MySQL 8 |
| SSL | Let's Encrypt + Certbot |
| Mail | Postfix |
| Cache | Redis |
| Security | Fail2Ban |
| OS | Ubuntu 24 LTS |

## Features — All Buttons Work

| Module | What it does |
|--------|-------------|
| 🌐 **Domains** | Add/delete/suspend/activate — creates real Nginx virtual hosts |
| 📁 **File Manager** | Browse `/var/www`, create folders, edit & delete files |
| 🗄️ **Databases** | Create/delete MySQL databases + users, backup to `.sql.gz` |
| 📧 **Email** | Add/remove Postfix virtual mailboxes |
| 🔒 **SSL** | Real `certbot` integration — installs Let's Encrypt certs |
| ⚙️ **Services** | Toggle Nginx, MySQL, Postfix, Redis, Fail2Ban, Cron via `systemctl` |
| 💾 **Backups** | Full/files backup with `tar.gz`, list and delete backups |
| 📜 **Logs** | Live log viewer — Activity, Nginx, Error, MySQL, Syslog |
| 🐘 **PHP** | Show installed PHP versions and active version |
| 📊 **Stats** | Live CPU, RAM, Disk from server |
| 🔐 **Auth** | Token-based login — first run sets your password |

## Quick Install (Ubuntu 24 Server)

```bash
git clone https://github.com/wpspoti/hostpro.git
cd hostpro
chmod +x install.sh
sudo bash install.sh
```

**Script asks:** Domain → Email → MySQL password → SSL?

**Then automatically:**
1. PHP 8.3 + FPM + all extensions
2. MySQL 8 + security hardening
3. Nginx + virtual host
4. HostPro files deployed to `/var/www/hostpro`
5. PHP-FPM sudo permissions for service management
6. Let's Encrypt SSL (optional)
7. Postfix, Redis, Fail2Ban installed
8. Systemd service + UFW rules

## First Login

1. Open `https://yourdomain.com` in browser
2. Enter any password → this becomes your admin password
3. Token saved in browser localStorage

## File Structure

```
hostpro/
├── index.html          # Frontend panel UI
├── api/
│   └── index.php       # PHP API backend (all system commands)
├── install.sh          # Ubuntu 24 auto-installer
└── README.md
```

## API Endpoints

All POST to `/api/index.php` with `X-Auth-Token` header:

```
server_info       — CPU, RAM, Disk, uptime
services_list     — List all service statuses
service_toggle    — Start/stop/restart a service
domains_list      — List Nginx virtual hosts
domain_add        — Create new virtual host
domain_delete     — Remove virtual host
domain_suspend    — Disable site
domain_activate   — Enable site
ssl_list          — List Let's Encrypt certs
ssl_install       — Run certbot
ssl_renew         — Force renew certificate
ssl_delete        — Delete certificate
db_list           — List MySQL databases
db_create         — Create DB + user
db_delete         — Drop database
db_backup         — mysqldump to .sql.gz
email_list        — List Postfix accounts
email_create      — Add virtual mailbox
email_delete      — Remove mailbox
files_list        — Browse /var/www
files_read        — Read file content
files_write       — Write file content
files_delete      — Delete file/folder
files_mkdir       — Create directory
backup_create     — tar.gz backup
backup_list       — List backups
logs              — Tail log files
php_versions      — List PHP installations
```

## Useful Commands

```bash
# Service
systemctl status hostpro
systemctl restart hostpro

# Logs
tail -f /var/log/nginx/hostpro_access.log
tail -f /var/log/hostpro/activity.log

# SSL
certbot renew --dry-run
certbot certificates

# PHP
php8.3 -v
systemctl restart php8.3-fpm

# MySQL
mysql -u root -p
```

## Requirements

- Ubuntu 24 LTS Server
- Root / sudo access
- Domain with DNS A record → server IP
- Open ports: 22, 80, 443

## License

MIT — github.com/wpspoti/hostpro
